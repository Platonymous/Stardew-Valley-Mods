ambience.ogg: "Nature sounds ambience.wav" by Elmarp
https://freesound.org/people/Elmarp/sounds/367007/

theme.ogg: "A Memory Away" by Tanner Helland
http://www.tannerhelland.com/28/a-memory-away/

select.ogg: "Deserve To Be Loved" by Tanner Helland
http://www.tannerhelland.com/12/deserve-to-be-loved/